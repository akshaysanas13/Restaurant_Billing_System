import React, { useEffect, useState } from 'react'
import $ from 'jquery'
import { ReactDOM } from 'react-dom'
import { Link } from 'react-router-dom';
 import DinnerBill from './DinnerBill';

function Dinner() {

    const  [arr2,setarr2]=useState([])
    const[flag,setFlag]=useState(false);
    const [dinner, setDinner] = useState([]);
    useEffect(() => {
        async function getData() {

            try {
                const output = await fetch("http://localhost:5000/getdinner")

                const cons = await output.json()

                setDinner(cons);

            } catch (err) {
                console.log(err)
            }

        }


        getData()
    }, [])


    const getMenuData=()=>{
        alert(111)
        setFlag(true)
    }
   
    const sendData = (event) => {
      
        const Mid = event.target.name;
       
        dinner.forEach(element => {
            if (Mid == element.id) {
              
                 
                console.log("element", element)
 
                setarr2([...arr2,element])
               
            }
        });
        localStorage.setItem("myItems", arr2);
        console.log(arr2)
    }
    return (
        <div className='d-flex p-5'>
          <div className="container">
          <h2 className='d-flex justify-content-center'> Order Book</h2>
             <table className="table shadow  bg-body rounded">
                 <thead>
                     <tr>
                         <th scope="col">Menu</th>
                         <th scope="col">Price</th>
                         <th scope="col">Add to cart</th>
                     </tr>
                 </thead>
                 <tbody>
 
 
                     {
                         dinner.map((data) =>
                             <tr> 
 
 
                                 <td>{data.MenuName}</td>
                                 <td>{data.price}</td>
 
                                 <td><div class="form-check">
                                     <input class="form-check-input" type="checkbox" value="" name={data.id} id="flexCheckDefault" onClick={sendData} />
                                     <label class="form-check-label" for="flexCheckDefault">
 
                                     </label>
                                 </div><td /></td>
 
 
                             </tr>
                         )
                     }
 
                 </tbody>
             </table>
             <input class="btn btn-primary" type="button" value="submit" onClick={getMenuData}/>
           
         </div>
         <div className='container table '>
             <div >
             {flag&& <DinnerBill item = {arr2}/>}
             </div>
             
         </div>
        </div>
     )
}

export default Dinner