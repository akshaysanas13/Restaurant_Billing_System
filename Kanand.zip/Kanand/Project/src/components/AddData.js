import React from 'react'
import { Link } from 'react-router-dom'
import './addData.css'
const AddData = () => {
  return (
    <div className="container-fluid mt-5 bg1">
    <h1 className='d-flex justify-content-center mb-5 '>
            Welcome Admin
          </h1>
          <div className="container d-flex justify-content-center mt-10">
          
            <Link to="/addBreakfast" className='px-4'> <input type="button" value="Add in BreakFast" className="btn btn-primary "></input></Link>
            <Link to="/addLunch" className='px-4'> <input type="button" value="Add in Lunch" className="btn btn-secondary px-2"></input></Link>
            <Link to="/addDinner" className='px-4'> <input type="button" value="Add in Dinner" className="btn btn-danger px-2"></input></Link>
            <Link to="/feedback" className='px-4'> <input type="button" value="Customer feedback" className="btn btn-secondary px-2"></input></Link>
            
          </div>
    </div>
  )
}

export default AddData
