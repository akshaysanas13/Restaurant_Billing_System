import axios from 'axios'
import React from 'react';
function AddLunch() {
    const handleSubmit = async (event) => {
        event.preventDefault()
        alert("Menu Added in Lunch");
        const MenuName = document.getElementById("name").value;
        const price = document.getElementById("price").value;

        console.log(MenuName, price);

        const object = { MenuName: MenuName, price: price }
        console.log(object);
        try {
            const obj = await axios.post("http://localhost:5000/postlunch", object)
            console.log(obj.data)
        }
        catch (err) {
            console.log(err)
        }

    }

    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className="col">
                        <form>

                            <h1 className="text-secondary text-center">Add Lunch</h1>
                            <div className="form-group mb-3">
                                <label for="name">menu name</label>
                                <input type="text" id="name" className="form-control" placeholder="Enter menu name" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="email">Price</label>
                                <input type="text" id="price" className="form-control" placeholder="enter price" />
                            </div>



                            <div className="form-group  mt-5">

                                <input type="button" className="btn btn-primary" value="Add " onClick={handleSubmit} />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default AddLunch