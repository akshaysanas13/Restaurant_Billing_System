import React, { useEffect, useState } from 'react'


const DinnerBill = (props) => {
    const [dinnerBill, setDinnerBill] = useState([]);
    const [total, setTotal] = useState();
     
     

    useEffect(() => {
        async function printdata() {
            try {

                console.log(props.item)
                
                
                setDinnerBill(props.item);

            } catch (err) {
                console.log(err)
            }
        }
        printdata()
    }, [props.item])

     

    const getTotal = () => {
        alert("get Total called")
        const data1=(props.item)
                let sum = data1.reduce((acc, cur) => (acc + cur.price), 0);
                setTotal(sum)
                console.log(  sum)
               

          
    }

     return (
        <div class="container ">
            <h2 className='d-flex justify-content-center'>Bill</h2>
            <table class="table shadow    bg-body rounded">

                <thead>
                    <tr>
                        <th>Menu Name</th>
                        <th>Price</th>

                    </tr>
                </thead>

                <tbody>
                    {
                        dinnerBill.map((data) =>
                            <tr>

                                <td>{data.MenuName}</td>
                                <td>{data.price}</td>




                            </tr>


                        )


                            


                    }
                </tbody>
                <tr>
                <input type="button" className='btn btn-success mt-2 d-flex justify-content-center' value="get Bill" onClick={getTotal} />
                <span><th className='d-flex justify-content-center' >Total <span className='px-2'><td className='d-flex justify-content-center '> {total}  ₹</td> </span></th> </span>
               
                </tr>
                            
            </table>
             





        </div>
    )
}

export default DinnerBill