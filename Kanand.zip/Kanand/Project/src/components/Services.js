import React from 'react'
import { Link } from 'react-router-dom'
 
import './Services.css'
const Services = () => {
  return (
<div>
<div class="feature">
            <div class="container">
               
                <div class="row">
                    <div class="col-lg-5">
                        <div class="section-header">
                            <p>Why Choose Us</p>
                            <h2>Our Key Features</h2>
                        </div>
                        <div class="feature-text">
                            <div class="feature-img">
                                <div class="row">
                                    <div class="col-6">
                                        <img src="img/feature-1.jpg" alt="feature"/>
                                    </div>
                                    <div class="col-6">
                                        <img src="img/feature-2.jpg" alt="feature"/>
                                    </div>
                                    <div class="col-6">
                                        <img src="img/feature-3.jpg" alt="feature"/>
                                    </div>
                                    <div class="col-6">
                                        <img src="img/feature-4.jpg" alt="feature"/>
                                    </div>
                                </div>
                            </div>
                            <p>
                                Lorem ipsum dolor sit amet consec adipis elit. Phasel nec preti mi. Curabit facilis ornare velit non vulputa. Aliquam metus tortor, auctor id gravida condime, viverra quis sem. Curabit non nisl nec nisi sceleri maximus 
                            </p>
                            <Link class="btn custom-btn tabl"  >Book A Table</Link>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="feature-item">
                                    <i class="flaticon-cooking"></i>
                                    <h3>World’s best Chef</h3>
                                   <p>We provide best Chef in our KANAND</p>
                                   <p>A recipe has no soul. You, as the cook ,must bring soul to the recipe</p>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="feature-item">
                                    <i class="flaticon-vegetable"></i>
                                    <h3>Natural ingredients</h3>
                                   <p>in KANAND we use fresh vegetable and all natural ingredients.</p>
                                   <p>We belive, Cooking is the caring and nurturing act.it's kind of ultimate gift for someone,to cook for them</p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="feature-item">
                                    <i class="flaticon-medal"></i>
                                    <h3>Best quality products</h3>
                                   <p>We're dedicated to improving the way we prepare our quality food and the ingredients that go into it.</p>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="feature-item">
                                    <i class="flaticon-meat"></i>
                                    <h3>Fresh vegetables & Meet</h3>
                                    <p>in KANAND we use fresh vegetable and all natural ingredients.</p>
                                    <p>We’re passionate about our food. That’s why we’re committed to always evolving what matters to you.</p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="feature-item">
                                    <i class="flaticon-courier"></i>
                                    <h3>Fastest door delivery</h3>
                                    <p>
                                        Lorem ipsum dolor sit amet elit. Phasel nec preti mi. Curabit facilis ornare velit non vulput metus tortor
                                    </p>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
 

  )
}

export default Services