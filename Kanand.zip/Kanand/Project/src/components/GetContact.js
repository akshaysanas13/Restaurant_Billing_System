import React from 'react'
import { useEffect,useState } from 'react';
const GetContact = () => {

    const [contact, setContact] = useState([]);
    useEffect(() => {
        async function getData() {

            try {
                const output = await fetch("http://localhost:5000/getcontact")

                const cons = await output.json()

                setContact(cons);

            } catch (err) {
                console.log(err)
            }

        }


        getData()
    }, [])

    return (
        <div className='mt-5 p-5'>
          <div className="container">
          <h2 className='d-flex justify-content-center'> Customer Queries</h2>
             <table className="table shadow  bg-body rounded mt-3">
                 <thead>
                     <tr>
                         <th scope="col">Cus.ID</th>
                         <th scope="col">Customer Name</th>
                         <th scope="col">Subject</th>
                         <th scope="col">Message to You</th>
                     </tr>
                 </thead>
                 <tbody>
 
 
                     {
                         contact.map((data) =>
                             <tr> 
 
                                 <td>{data.cid}</td>
                                 <td>{data.name}</td>
                                 <td>{data.subject}</td>
                                 <td>{data.message}</td>
 
                    
 
 
                             </tr>
                         )
                     }
 
                 </tbody>
             </table>
              
           
         </div>
          
        </div>
     )
}

export default GetContact