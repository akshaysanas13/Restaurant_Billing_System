import React from 'react'
import './aboutus.css'
import { Link } from 'react-router-dom'
const AboutUs = () => {
  return (
    <div class="about">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-img">
                            {/* <iframe src="img/about.jpg" alt="Image"/>
                            <button type="button" class="btn-play" data-toggle="modal" data-src="https://www.youtube.com/watch?v=BjfZ9XtN2Uw" data-target="#videoModal">
                                <span></span>
                            </button> */}
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/BjfZ9XtN2Uw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-content">
                            <div class="section-header">
                                <p>About Us</p>
                                <h2>Cooking Since 2022</h2>
                            </div>
                            <div class="about-text">
                                <p>
                                Relish a selection of your favourite delicacies from our restaurants and enjoy the KANAND Experience in the comfort of your home. Our culinary team has curated a menu with a wide range of international cuisines and Indian delicacies. Prepared and packaged using the highest standards of cleanliness and hygiene.
                                </p>
                                <p>We’re passionate about our food. That’s why we’re committed to always evolving what matters to you.</p>
                                <Link class="btn btn-success"  to="/blog">Blog</Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  )
}

export default AboutUs