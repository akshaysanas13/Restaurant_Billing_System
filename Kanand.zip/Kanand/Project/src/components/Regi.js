import React from 'react'
import './reg.css'

const Regi = () => {
  return (
    <div className="form1">
      <div class="container">
        <div class="title">Registration</div>
        <form action="#">
          <div class="user__details">
            <div class="input__box">
              <span class="details">Admin Name</span>
              <input type="text" placeholder="E.g: John Smith" required />
            </div>
            <div class="input__box">
              <span class="details">Username</span>
              <input type="text" placeholder="johnWC98" required />
            </div>
            <div class="input__box">
              <span class="details">Email</span>
              <input type="email" placeholder="johnsmith@hotmail.com" required />
            </div>
            <div class="input__box">
              <span class="details">Phone Number</span>
              <input type="tel" pattern="[789][0-9]{3}" placeholder="9192 9394 95" required />
            </div>

            <div class="input__box">
              <span class="details">Password</span>
              <input type="password" placeholder="********" required />
            </div>


          </div>

          <div class="button">
            <input type="submit" value="User login" />
          </div>
        </form>
      </div>
    </div>
  )
}

export default Regi