import './nav.css'
import React from 'react'
import { Link } from 'react-router-dom'
function Nav(){
return(
     <div className='sticky-top'>
        <nav class="   navbar navbar-expand-lg bg-light1 ">
  <div class="container-fluid">
    <Link class="navbar-brand"  >KANAND </Link>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <Link class="nav-link active" aria-current="page" to="/home" style={{color:'white'}}>Home</Link>
        </li>
        <li class="nav-item">
          <Link class="nav-link"to ="/about"  >About</Link>
        </li>
        <li class="nav-item">
          <Link class="nav-link" to="/service">Services</Link>
        </li>
        <li class="nav-item dropdown">
          <Link class="nav-link dropdown-toggle" to="./menu" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           Menu
          </Link>
          <ul class="dropdown-menu">
            <Link class="dropdown-item"  to="/breakfast">Breakfast</Link>  
            <Link class="dropdown-item"  to="/lunch">Lunch</Link>  
            <Link class="dropdown-item"  to="/dinner">Dinner</Link>  
          </ul>
        </li>
       

        <li class="nav-item">
        <Link class="nav-link" to="/login">Log-in</Link>  
        </li>
        
        {/* <li class="nav-item">
        <Link class="nav-link" to="/sign-up">Sign-up</Link>  
        </li> */}

        <li class="nav-item">
          <Link class="nav-link" to="/contact">Contact </Link>
        </li>

        <li class="nav-item dropdown">
          <Link class="nav-link  "  to="/admin" role="button"    >
         Admin
          </Link>
          {/* <ul class="dropdown-menu">
            <Link class="dropdown-item"  to="/addBreakfast">Add Breakfast</Link>  
            <Link class="dropdown-item"  to="/addLunch" >Add Lunch</Link>  
            <Link class="dropdown-item"   to="/adddinner">Add Dinner</Link>  
          </ul> */}
        </li>
      </ul>
    </div>
  </div>
</nav>
     </div>
)
}

export default Nav