import React from 'react'
import { MidSection } from './midSection'
// import AboutUs from './aboutUs'
// import Carousel from './Carousel'

const Home = () => {
  return (
    <div>
        <MidSection/>
        {/* <Carousel/> */}
    </div>
  )
}

export default Home