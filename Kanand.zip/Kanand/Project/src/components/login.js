import React from 'react'
import { Link } from 'react-router-dom'
import './login.css'
function Login() {
  return (
    <div className='container container fluid '>
        <form className="form shadow p-3 mb-5 bg-body rounded">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">username</label>
    <input type="text" class="form-control" id="username" aria-describedby="emailHelp"/>
    
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" id="password"/>
  </div>
   
  <button type="submit" class="btn btn-success">Sign In</button>

  <Link class="nav-link" to="/sign-up" style={{color:'blue'}}>dont have an account?</Link>
  <Link class="nav-link" to="/home" style={{color:'blue'}}>forgot password?</Link>
</form>    
    </div>
  )
}

export default Login