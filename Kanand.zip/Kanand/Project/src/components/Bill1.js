import React from 'react'

const Bill1 = () => {
  return (
    <div> 
    
    
    </div>
  )
}

export default Bill1