import React from 'react'
import './Admin.css'
 
import { Link, useNavigate } from 'react-router-dom'
const Admin = () => {
    const [uname, setUname] = React.useState("");
    const [pass, setPass] = React.useState("");
    const [err, setErr] = React.useState(false);
    const [data, setData] = React.useState([]);
    const [id,setId]=React.useState("");
    const navigate = useNavigate();

    const handleUname = (event) => {
        setUname(event.target.value)
    }
    const handlePassword = (event) => {
        setPass(event.target.value)
    }


    const handleLogin = (event) => {
        event.preventDefault();
        const getData = async () => {
           
            const obj = await fetch("http://localhost:5000/login/" + uname + "/" + pass)
            // console.log(obj)
            const arr = await obj.json();
            console.log(arr);
            if(uname==="admin" && pass==="admin@123")
            {
                navigate("/addData");
            }
            else if(arr.length){

                // alert("welcome");
                const data=JSON.stringify(arr[0]);
                localStorage.setItem("obj",data);
                navigate("/admin");
            }
            else {
                setErr("Invalid username or password.");
            }
                
            setData(arr[0]);
    }
    getData()
    }
  return (
    <div className='bg2'>
          
    <div className='container container fluid  '>
        <form className="form shadow p-3 form  bg-body rounded">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">username</label>
    <input type="text" class="form-control" id="username" aria-describedby="emailHelp" onChange={handleUname}/>
    
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" id="password" onChange={handlePassword}/>
  </div>
   
 <Link to="/addData"> <button type="submit" class="btn btn-success" onChange={handleLogin}>Admin Account</button></Link>

   
</form>    
    </div>
  
    </div>
  )
}

export default Admin