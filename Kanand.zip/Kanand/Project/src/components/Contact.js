import React from 'react'
import './contact.css'
import { Link } from 'react-router-dom'
import axios from 'axios'
const Contact = () => {

    const handleSubmit = async (event) => {
        event.preventDefault()
        alert(" your feedback send to admin");
        const Name = document.getElementById("name").value;
        const Email = document.getElementById("email").value;
        const Subject=document.getElementById("subject").value;
        const Message=document.getElementById("message").value;
         

        const object = { name: Name, email: Email, subject:Subject,message: Message }
        console.log(object);
        try {
            const obj = await axios.post("http://localhost:5000/postcontact", object)
            console.log(obj.data)
        }
        catch (err) {
            console.log(err)
        }

    }

  return (
     
        <div class="contact">
            <div class="container">
                <div class="section-header text-center">
                    <p style={{color:'#97C4B8'}}>Contact Us</p>
                    <h2 style={{color:'#CCF3EE'}}>Customer feedback</h2>
                </div>
                <div class="row align-items-center contact-information">
                    <div class="col-md-6 col-lg-3">
                        <div class="contact-info">
                            <div class="contact-icon">
                                <i class="fa fa-map-marker-alt"></i>
                            </div>
                            <div class="contact-text">
                                <h3>Address</h3>
                                <p>Katraj-Pune Maharashtra Pune</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="contact-info">
                            <div class="contact-icon">
                                <i class="fa fa-phone-alt"></i>
                            </div>
                            <div class="contact-text">
                                <h3>Call Us</h3>
                                <p>+9192 9394 95</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="contact-info">
                            <div class="contact-icon">
                                <i class="fa fa-envelope"></i>
                            </div>
                            <div class="contact-text">
                                <h3>Email Us</h3>
                                <p>info@example.com</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="contact-info">
                            <div class="contact-icon">
                                <i class="fa fa-share"></i>
                            </div>
                            <div class="contact-text">
                                <h3>Follow Us</h3>
                                <div class="contact-social">
                                    <Link><i class="fab fa-twitter"></i></Link>
                                    <Link to=""><i class="fab fa-facebook-f"></i></Link>
                                    <Link to=""><i class="fab fa-youtube"></i></Link>
                                    <Link href=""><i class="fab fa-instagram"></i></Link>
                                    <Link href=""><i class="fab fa-linkedin-in"></i></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row contact-form">
                    
                    <div class="col-md-6">
                        <div id="success"></div>
                        <form name="sentMessage" id="contactForm" novalidate="novalidate">
                            <div class="control-group">
                                <input type="text" class="form-control" id="name" placeholder="Your Name" required="required" data-validation-required-message="Please enter your name" style={{color:'white'}}/>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <input type="email" class="form-control" id="email" placeholder="Your Email" required="required" data-validation-required-message="Please enter your email" style={{color:'white'}}/>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <input type="text" class="form-control" id="subject" placeholder="Subject" required="required" data-validation-required-message="Please enter a subject" style={{color:'white'}}/>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <textarea class="form-control" id="message" placeholder="Message" required="required" data-validation-required-message="Please enter your message" style={{color:'white'}}></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div>
                                <button class="btn btn-success" type="submit" id="sendMessageButton" onClick={handleSubmit}>Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
   
  )
}

export default Contact