// import logo from './logo.svg';
import './App.css';
import Nav from './components/nav'

import { BrowserRouter, Route, Routes } from "react-router-dom";
import AboutUs from './components/AboutUs';
import Login from './components/login';
import Footer from './components/Footer';
import Regi from './components/Regi';
import Home from './components/home';
import Breakfast from './components/Breakfast';
import Lunch from './components/Lunch';
import Dinner from './components/Dinner';
import Bill from './components/Bill';
import Services from './components/Services';
import Contact from './components/Contact';
import AddBreakfast from './components/AddBreakfast';
import AddLunch from './components/AddLunch';
import AddDinner from './components/AddDinner';
import Blog from './components/Blog';
import Admin from './components/Admin';
import AddData from './components/AddData';
import GetContact from './components/GetContact';


function App() {
  return (

    <div>
      <BrowserRouter>
        <Nav />

        <Routes>


          <Route path='/home' element={<Home />} />
          <Route path='/about' element={<AboutUs />} />
          <Route path='/service' element={<Services />} />
          <Route path='/login' element={<Login />} />
          <Route path='/sign-up' element={<Regi />} />
          <Route path='/breakfast' element={<Breakfast />} />
          <Route path='/Bill/:id' element={<Bill />} />
          <Route path='/lunch' element={<Lunch />} />
          <Route path='/dinner' element={<Dinner />} />
          <Route path='/contact' element={<Contact />} />
          <Route path='/admin' element={<Admin />} />
          <Route path='/blog' element={<Blog />} /> 
          <Route path='/addData' element={<AddData />} /> 


          <Route path='/addBreakfast' element={<AddBreakfast />} />
          <Route path='/addLunch' element={<AddLunch />} />
          <Route path='/adddinner' element={<AddDinner />} />
          <Route path='/bill' element={<Bill/>} />
          <Route path='/feedback' element={<GetContact/>} />
        


        </Routes>

        <Footer />
      </BrowserRouter>

    </div>

  );
}

export default App;
