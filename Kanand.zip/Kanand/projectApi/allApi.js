const Express = require("express")
const con = require("./projectConnection");
const app = Express();
const cors = require('cors')
app.use(cors());

app.get("/getbreakfast", (req, res) => {
  con.query("select * from breakfast", function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.get("/getbreakfast/search/:id", (req, res) => {
  let id = req.params.id;
  con.query("select * from breakfast where id=?", [id], function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.get("/getlunch", (req, res) => {
  con.query("select * from lunchMenu", function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})


//////////search for lunch///////////

app.get("/getlunch/search/:id", (req, res) => {
  let id = req.params.id;
  con.query("select * from lunchMenu where id=?", [id], function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

app.get("/getdinner", (req, res) => {
  con.query("select * from dinnerMenu", function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})

const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


/* post breakfast */
app.post('/postbreakfast', (req, res) => {
  const MenuName = req.body.MenuName;
  const price = req.body.price;
  const id = req.body.id;
  con.query('insert into breakfast values(?,?,?)', [id, MenuName, price], (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send(result);
    }
  })
})



/**post lunch */
app.post('/postlunch', (req, res) => {
  const MenuName = req.body.MenuName;
  const price = req.body.price;
  const id = req.body.id;
  con.query('insert into lunchMenu values(?,?,?)', [id, MenuName, price], (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send("data posted");
    }
  })
})




app.post('/postdinner', (req, res) => {
  const MenuName = req.body.MenuName;
  const price = req.body.price;
  const id = req.body.id;
  con.query('insert into dinnerMenu values(?,?,?)', [id, MenuName, price], (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send("data posted");
    }
  })
})

/*get  api for login to admin*/

app.get("/login/:username/:password",(req,res)=>{
  let username=req.params.username;
  let password=req.params.password;
  con.query("select * from reg where username=? and password=?",[username,password],function(err,result){
    if(err){
      res.send("error")
    }else{
      res.send(result)
      return result;
    }
  })
})

//api for post data of admin details
app.post('/postadmin', (req, res) => {
  const rid = req.body.rid;
  const name = req.body.name;
  const username = req.body.username;
  const email = req.body.email;
  const phone = req.body.username;
  const password = req.body.phone;
   
  con.query('insert into reg values(?,?,?,?,?,?)', [rid,name,username,email,phone,password], (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send("data posted");
    }
  })
})

// app.post('/postlogin',(req,res)=>{
//   const id=req.body.id;
//   const email=req.body.email;
//   const uPassword=req.body.uPassword;
//   con.query('insert into Login values(?,?,?)',[id,email,uPassword],(err,result)=>{
//     if(err){
//       console.log(err);
//     }else{
//       res.send("data posted");
//     }
//   })
// })



//api for contact 

app.post('/postcontact', (req, res) => {
  const cid = req.body.cid;
  const name = req.body.name;
  const email = req.body.email;
  const subject = req.body.subject;
  const message = req.body.message;
  
   
  con.query('insert into contact values(?,?,?,?,?)', [cid,name,email,subject,message], (err, result) => {
    if (err) {
      console.log(err);
    } else {
      res.send("data posted");
    }
  })
})


//get api for customer contact page
app.get("/getcontact", (req, res) => {
  con.query("select * from contact", function (err, result) {
    if (err) {
      res.send("error")
    } else {
      res.send(result)
    }
  })
})



app.listen(5000, (err) => {
  if (err) {
    console.log(err);
  } else {
    console.log("on port 5000")
  }
})